# Maktabah Riyadlus Sholihin — Android starter

Aplikasi awal rak kitab PDF + pembaca halaman + coretan stylus/touch.

## Fitur yang sudah ada
- Import PDF dari penyimpanan Android (file disalin ke penyimpanan privat aplikasi)
- Rak kitab sederhana
- Pembaca PDF per halaman (Android `PdfRenderer`)
- Navigasi halaman
- Lapisan coretan stylus/jari di atas halaman

## Cara membuka
1. Instal Android Studio (versi stabil terbaru).
2. Pilih **Open** dan buka folder `KitabKuAndroid`.
3. Tunggu Gradle Sync.
4. Jalankan ke tablet/HP Android (min Android 8.0 / API 26).

## Catatan penting untuk versi berikutnya
Ini adalah prototipe awal, belum versi produksi:
- Coretan saat ini hanya sementara (belum disimpan per halaman).
- Judul kitab masih menggunakan nama file/URI sederhana.
- Belum ada pencarian teks, sinkronisasi antarperangkat, ekspor catatan, atau efek page-turn animasi.
- Untuk membuat APK: Android Studio → Build → Build APK(s).

Nama aplikasi **Maktabah Riyadlus Sholihin**.
