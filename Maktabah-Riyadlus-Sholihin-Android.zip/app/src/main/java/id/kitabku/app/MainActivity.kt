package id.kitabku.app

import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.Image
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

data class Book(val id: String, val title: String, val path: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KitabKuApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KitabKuApp() {
    val context = LocalContext.current
    var books by remember { mutableStateOf(listOf<Book>()) }
    var selected by remember { mutableStateOf<Book?>(null) }
    var page by remember { mutableIntStateOf(0) }
    var pageCount by remember { mutableIntStateOf(0) }
    var pageBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var showNotes by remember { mutableStateOf(true) }
    var strokes by remember { mutableStateOf(listOf<List<Offset>>()) }
    var currentStroke by remember { mutableStateOf(listOf<Offset>()) }

    val importPdf = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            context.contentResolver.openInputStream(uri)?.use { input ->
                val dir = File(context.filesDir, "books").apply { mkdirs() }
                val fileName = "kitab_${System.currentTimeMillis()}.pdf"
                val target = File(dir, fileName)
                FileOutputStream(target).use { output -> input.copyTo(output) }
                val newBook = Book(fileName, uri.lastPathSegment?.substringAfterLast("/") ?: "Kitab PDF", target.absolutePath)
                books = books + newBook
            }
        }
    }

    LaunchedEffect(selected, page) {
        val book = selected ?: return@LaunchedEffect
        isLoading = true
        val result = withContext(Dispatchers.IO) {
            try {
                val pfd = ParcelFileDescriptor.open(File(book.path), ParcelFileDescriptor.MODE_READ_ONLY)
                val renderer = PdfRenderer(pfd)
                pageCount = renderer.pageCount
                if (page in 0 until renderer.pageCount) {
                    val pdfPage = renderer.openPage(page)
                    val bitmap = Bitmap.createBitmap(
                        (pdfPage.width * 1.4f).toInt().coerceAtLeast(1),
                        (pdfPage.height * 1.4f).toInt().coerceAtLeast(1),
                        Bitmap.Config.ARGB_8888
                    )
                    bitmap.eraseColor(AndroidColor.WHITE)
                    pdfPage.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    pdfPage.close()
                    renderer.close()
                    pfd.close()
                    bitmap
                } else {
                    renderer.close(); pfd.close(); null
                }
            } catch (_: Exception) { null }
        }
        pageBitmap = result
        isLoading = false
    }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Color(0xFF356B4B), secondary = Color(0xFFB78B52),
        background = Color(0xFFF7F4EC), surface = Color(0xFFFFFDF8)
    )) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(selected?.title ?: "Maktabah Riyadlus Sholihin", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        if (selected != null) IconButton(onClick = { selected = null; page = 0 }) {
                            Icon(Icons.Default.ArrowBack, "Kembali")
                        } else Icon(Icons.Default.MenuBook, contentDescription = null,
                            modifier = Modifier.padding(start = 16.dp), tint = MaterialTheme.colorScheme.primary)
                    },
                    actions = {
                        if (selected == null) IconButton(onClick = { importPdf.launch(arrayOf("application/pdf")) }) {
                            Icon(Icons.Default.Add, "Tambah kitab")
                        }
                    }
                )
            },
            floatingActionButton = {
                if (selected == null) FloatingActionButton(onClick = { importPdf.launch(arrayOf("application/pdf")) }) {
                    Icon(Icons.Default.Add, "Tambah PDF")
                }
            }
        ) { padding ->
            if (selected == null) {
                ShelfScreen(books, padding, onOpen = { selected = it; page = 0; strokes = emptyList() },
                    onImport = { importPdf.launch(arrayOf("application/pdf")) })
            } else {
                ReaderScreen(
                    modifier = Modifier.padding(padding), title = selected!!.title,
                    page = page, pageCount = pageCount, bitmap = pageBitmap, loading = isLoading,
                    showNotes = showNotes, onToggleNotes = { showNotes = !showNotes },
                    onPrev = { if (page > 0) { page--; strokes = emptyList() } },
                    onNext = { if (page < pageCount - 1) { page++; strokes = emptyList() } },
                    strokes = strokes, currentStroke = currentStroke,
                    onStrokeStart = { currentStroke = listOf(it) },
                    onStrokeAdd = { currentStroke = currentStroke + it },
                    onStrokeEnd = { strokes = strokes + listOf(currentStroke); currentStroke = emptyList() },
                    onClearNotes = { strokes = emptyList(); currentStroke = emptyList() }
                )
            }
        }
    }
}

@Composable
fun ShelfScreen(books: List<Book>, padding: PaddingValues, onOpen: (Book) -> Unit, onImport: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).padding(18.dp)) {
        Text("Maktabah Riyadlus Sholihin", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color(0xFF28543B))
        Text("Simpan dan baca kitab PDF dalam satu rak.", color = Color.Gray, modifier = Modifier.padding(top = 4.dp, bottom = 18.dp))
        if (books.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.MenuBook, null, tint = Color(0xFF8AAB92), modifier = Modifier.size(72.dp))
                    Text("Rak kitab masih kosong", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp))
                    Text("Tambahkan kitab PDF untuk mulai membaca.")
                    Button(onClick = onImport, modifier = Modifier.padding(top = 12.dp)) { Text("Tambah kitab PDF") }
                }
            }
        } else {
            LazyVerticalGrid(columns = GridCells.Adaptive(145.dp), horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(books) { book ->
                    Card(onClick = { onOpen(book) }, shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.padding(14.dp)) {
                            Box(Modifier.fillMaxWidth().height(135.dp).background(Color(0xFFE9E2D3), RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Book, null, tint = Color(0xFF356B4B), modifier = Modifier.size(54.dp))
                            }
                            Text(book.title, fontWeight = FontWeight.Bold, maxLines = 2, modifier = Modifier.padding(top = 10.dp))
                            Text("PDF • Buka kitab", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReaderScreen(
    modifier: Modifier, title: String, page: Int, pageCount: Int, bitmap: Bitmap?, loading: Boolean,
    showNotes: Boolean, onToggleNotes: () -> Unit, onPrev: () -> Unit, onNext: () -> Unit,
    strokes: List<List<Offset>>, currentStroke: List<Offset>,
    onStrokeStart: (Offset) -> Unit, onStrokeAdd: (Offset) -> Unit, onStrokeEnd: () -> Unit,
    onClearNotes: () -> Unit
) {
    Column(modifier.fillMaxSize().background(Color(0xFFF0ECE2))) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Halaman ${page + 1} / ${pageCount.coerceAtLeast(1)}", fontWeight = FontWeight.Medium)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onToggleNotes) { Text(if (showNotes) "Sembunyikan catatan" else "Mode catatan") }
            TextButton(onClick = onClearNotes) { Text("Hapus coretan") }
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 10.dp), contentAlignment = Alignment.Center) {
            if (loading) CircularProgressIndicator()
            else if (bitmap != null) {
                Box(Modifier.fillMaxHeight().fillMaxWidth().background(Color.White, RoundedCornerShape(8.dp))) {
                    Image(bitmap.asImageBitmap(), contentDescription = "Halaman kitab PDF",
                        modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                    if (showNotes) {
                        Canvas(Modifier.fillMaxSize().pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { onStrokeStart(it) },
                                onDragEnd = onStrokeEnd,
                                onDrag = { change, _ -> onStrokeAdd(change.position); change.consume() }
                            )
                        }) {
                            (strokes + listOf(currentStroke)).forEach { stroke ->
                                for (i in 1 until stroke.size) {
                                    drawLine(Color(0xFF2457C5), stroke[i - 1], stroke[i], strokeWidth = 3.5f)
                                }
                            }
                        }
                    }
                }
            } else Text("PDF tidak dapat dibuka. Coba impor ulang kitab.")
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onPrev, enabled = page > 0) { Text("‹ Sebelumnya") }
            Button(onClick = onNext, enabled = page < pageCount - 1) { Text("Berikutnya ›") }
        }
    }
}
